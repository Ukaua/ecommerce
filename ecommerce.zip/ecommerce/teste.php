<?php
session_start();
$idusuario = $_SESSION['idusuario'];
require("conecta.php");
                            $total = 0;
                            foreach ($_SESSION['carrinho'] as $id => $qtd) {
                                $sql = "SELECT tb_produtos.*, tb_arquivos.* from tb_produtos,tb_arquivos where tb_produtos.idprodutos = tb_arquivos.id_produtos and idprodutos=$id";

                                $qr    = mysqli_query($conn, $sql);
                                $ln    = mysqli_fetch_assoc($qr);
                                
                                $nome  = $ln['nome'];
                                @$preco = number_format($ln['valor'], 2, ',', '.');
                                $sub   = number_format($ln['valor'] * $qtd, 2, ',', '.');
                                $total += $ln['valor'] * $qtd;

                                $usuario = mysqli_query($conn,"INSERT INTO tb_minhasCompras(nome,preco,valor_total,idusuario) VALUES ('$nome','$preco','$total','$idusuario')");
                                unset( $_SESSION['carrinho'] );
                                echo "<script language='javascript' type='text/javascript'> 
                                alert('Registro inserido com sucesso!');
                                window.location.href='index.php';
                                </script>";

                            }
                            

                               
                            
?>