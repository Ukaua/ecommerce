<?php
    session_start();
    $login = $_SESSION['login'];
    $inadmin = $_SESSION['inadmin'];
    // include 'conecta.php';
    // $pesquisa = mysqli_query($conn, "SELECT * FROM tb_usuarios where login = '$login' and inadmin = 1");
    //                 $row = mysqli_num_rows($pesquisa);
    //                 if($row > 0){
    //                     header('Location: admin/index.php');
    //                 } else {
    //                     header('location:index.php');
    //                 }
    if($inadmin == 0){
        header('Location: index.php');
    }
    else {
        header('Location: admin/index.php');
    }
?>