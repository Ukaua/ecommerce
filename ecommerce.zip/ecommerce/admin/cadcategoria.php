<?php

session_start();
    if(isset($_SESSION['inadmin'])){
        
    }else{
        header('Location: index.php');
    }
include 'conecta.php';

$categoria = $_POST['categoria'];
$sql = "INSERT INTO tb_categoria(categoria) VALUE ('$categoria')";
if (mysqli_query($conn, $sql)) {
    echo  "<script language='javascript' type='text/javascript'>
    alert('Produto Inserido com sucesso!');
    window.location.href='produtos.php'
    </script>";
} else {
    echo  "<script language='javascript' type='text/javascript'>
    alert('Registro não foi inserido!');
    window.location.href='cadastrar.php'
    </script>";
}